// John Smith
// 10/06/14
// ANALYZE Buggy Search v1 